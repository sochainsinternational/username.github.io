# 🍪 KarmasGoodies

A beautiful e-commerce web application for an artisanal bakery brand. Customers can browse handcrafted goodies, add items to cart, and place orders with **Cash on Delivery** payment.

![React](https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=white)
![Vite](https://img.shields.io/badge/Vite-7-646CFF?logo=vite&logoColor=white)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4-06B6D4?logo=tailwindcss&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-5-3178C6?logo=typescript&logoColor=white)

## ✨ Features

- 🏠 Beautiful landing page with hero, featured products & testimonials
- 🛍️ Product catalog with category filters, search & sorting
- 📄 Individual product pages with ingredients & related items
- 🛒 Shopping cart with quantity management
- 📋 Full checkout form with validation
- 💰 **Cash on Delivery** payment method
- 📱 Fully responsive (mobile, tablet, desktop)
- 🎨 Premium UI with amber/orange branding

## 🚀 Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) (v18 or higher)
- [npm](https://www.npmjs.com/) (comes with Node.js)

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/karmasgoodies.git

# Navigate to the project
cd karmasgoodies

# Install dependencies
npm install

# Start the development server
npm run dev
```

The app will be running at `http://localhost:5173`

### Build for Production

```bash
npm run build
```

The production files will be in the `dist/` folder.

## 📁 Project Structure

```
karmasgoodies/
├── src/
│   ├── components/       # UI Components
│   │   ├── Navbar.tsx
│   │   ├── Hero.tsx
│   │   ├── FeaturedProducts.tsx
│   │   ├── Features.tsx
│   │   ├── Testimonials.tsx
│   │   ├── CTABanner.tsx
│   │   ├── ProductGrid.tsx
│   │   ├── ProductCard.tsx
│   │   ├── ProductDetail.tsx
│   │   ├── Cart.tsx
│   │   ├── Checkout.tsx
│   │   ├── OrderConfirmation.tsx
│   │   └── Footer.tsx
│   ├── context/
│   │   └── CartContext.tsx   # Global state management
│   ├── data/
│   │   └── products.ts      # Product catalog data
│   ├── types/
│   │   └── index.ts         # TypeScript type definitions
│   ├── App.tsx              # Main app with routing
│   ├── main.tsx             # Entry point
│   └── index.css            # Global styles
├── index.html
├── package.json
├── tsconfig.json
└── vite.config.ts
```

## 🛠️ Tech Stack

| Technology | Purpose |
|------------|---------|
| React 19 | UI framework |
| Vite 7 | Build tool & dev server |
| TypeScript | Type safety |
| Tailwind CSS 4 | Styling |
| Lucide React | Icons |

## 🌐 Deployment

### Deploy to Vercel (Recommended)
```bash
npm i -g vercel
vercel
```

### Deploy to Netlify
Drag and drop the `dist/` folder to [Netlify](https://app.netlify.com/drop)

### Deploy to GitHub Pages
1. Install gh-pages: `npm install -D gh-pages`
2. Add to package.json scripts: `"deploy": "npm run build && gh-pages -d dist"`
3. Run: `npm run deploy`

## 📝 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

Made with ❤️ and good karma by **KarmasGoodies**
