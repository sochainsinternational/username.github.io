export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  rating: number;
  reviews: number;
  badge?: string;
  ingredients?: string[];
}

export interface CartItem extends Product {
  quantity: number;
}

export interface OrderForm {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  notes: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  customer: OrderForm;
  total: number;
  date: string;
  status: string;
}

export type Page = 'home' | 'shop' | 'product' | 'cart' | 'checkout' | 'confirmation';
