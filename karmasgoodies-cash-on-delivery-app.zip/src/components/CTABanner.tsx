import { ArrowRight, Sparkles } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function CTABanner() {
  const { setCurrentPage } = useCart();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 p-8 sm:p-12 lg:p-16">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2" />

        <div className="relative text-center max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-1.5 mb-6">
            <Sparkles className="w-4 h-4 text-white" />
            <span className="text-sm font-semibold text-white">Limited Time Offer</span>
          </div>

          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            Get 15% Off Your First Order!
          </h2>
          <p className="text-white/90 text-lg mb-8 max-w-lg mx-auto">
            Use code <span className="font-bold bg-white/20 px-2 py-0.5 rounded">KARMA15</span> at checkout.
            Plus enjoy free delivery on orders over $50!
          </p>

          <button
            onClick={() => setCurrentPage('shop')}
            className="group inline-flex items-center gap-2 bg-white text-amber-700 hover:bg-amber-50 px-8 py-4 rounded-full text-lg font-bold shadow-xl hover:shadow-2xl transition-all cursor-pointer"
          >
            Order Now
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
}
