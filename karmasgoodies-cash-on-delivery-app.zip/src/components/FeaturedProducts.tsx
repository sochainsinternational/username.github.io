import { ArrowRight, Star, Sparkles } from 'lucide-react';
import { products } from '../data/products';
import { useCart } from '../context/CartContext';

export default function FeaturedProducts() {
  const { addToCart, setCurrentPage, setSelectedProductId } = useCart();

  const featured = products.filter(p => p.badge).slice(0, 4);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 bg-amber-100 rounded-full px-4 py-1.5 mb-4">
          <Sparkles className="w-4 h-4 text-amber-600" />
          <span className="text-sm font-semibold text-amber-700">Customer Favorites</span>
        </div>
        <h2
          className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4"
          style={{ fontFamily: 'Playfair Display, serif' }}
        >
          Most Loved Goodies
        </h2>
        <p className="text-gray-500 text-lg max-w-2xl mx-auto">
          Our top-rated treats that keep customers coming back for more
        </p>
      </div>

      {/* Products */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {featured.map(product => (
          <div
            key={product.id}
            className="group bg-white rounded-2xl shadow-sm hover:shadow-xl border border-gray-100 hover:border-amber-200 transition-all duration-300 overflow-hidden cursor-pointer"
            onClick={() => {
              setSelectedProductId(product.id);
              setCurrentPage('product');
            }}
          >
            <div className="relative aspect-square overflow-hidden bg-amber-50">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '';
                  (e.target as HTMLImageElement).parentElement!.innerHTML = '<div class="w-full h-full flex items-center justify-center text-6xl bg-gradient-to-br from-amber-100 to-orange-100">🧁</div>';
                }}
              />
              {product.badge && (
                <span className="absolute top-3 left-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-md">
                  {product.badge}
                </span>
              )}
            </div>
            <div className="p-4">
              <div className="flex items-center gap-1 mb-2">
                <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                <span className="text-xs font-semibold text-gray-700">{product.rating}</span>
                <span className="text-xs text-gray-400">({product.reviews})</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-1" style={{ fontFamily: 'Playfair Display, serif' }}>
                {product.name}
              </h3>
              <p className="text-sm text-gray-500 line-clamp-2 mb-3">{product.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-gray-900">${product.price.toFixed(2)}</span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    addToCart(product);
                  }}
                  className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm font-semibold shadow-md hover:shadow-lg transition-all cursor-pointer"
                >
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* View All */}
      <div className="text-center mt-12">
        <button
          onClick={() => setCurrentPage('shop')}
          className="group inline-flex items-center gap-2 bg-white border-2 border-amber-300 text-amber-700 hover:bg-amber-50 px-8 py-3 rounded-full font-semibold transition-all cursor-pointer"
        >
          View All Goodies
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
}
