import { ShoppingCart, Search, Menu, X, Sparkles } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useState } from 'react';

export default function Navbar() {
  const { totalItems, setCurrentPage, currentPage, searchQuery, setSearchQuery } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Home', page: 'home' as const },
    { label: 'Shop', page: 'shop' as const },
    { label: 'Cart', page: 'cart' as const },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-amber-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <button
            onClick={() => setCurrentPage('home')}
            className="flex items-center gap-2 group cursor-pointer"
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 bg-gradient-to-br from-amber-400 to-orange-500 rounded-xl flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow">
              <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg sm:text-xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent leading-tight" style={{ fontFamily: 'Playfair Display, serif' }}>
                KarmasGoodies
              </span>
              <span className="text-[9px] sm:text-[10px] text-amber-600/70 tracking-[0.2em] uppercase leading-tight">
                Handcrafted with Love
              </span>
            </div>
          </button>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(link => (
              <button
                key={link.page}
                onClick={() => setCurrentPage(link.page)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 cursor-pointer ${
                  currentPage === link.page
                    ? 'bg-amber-100 text-amber-800'
                    : 'text-gray-600 hover:text-amber-700 hover:bg-amber-50'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Search + Cart */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="hidden sm:flex items-center bg-amber-50 rounded-full px-3 py-2 border border-amber-100 focus-within:border-amber-300 focus-within:ring-2 focus-within:ring-amber-100 transition-all">
              <Search className="w-4 h-4 text-amber-500 mr-2" />
              <input
                type="text"
                placeholder="Search goodies..."
                value={searchQuery}
                onChange={e => {
                  setSearchQuery(e.target.value);
                  if (currentPage !== 'shop') setCurrentPage('shop');
                }}
                className="bg-transparent text-sm text-gray-700 placeholder-amber-400 outline-none w-32 lg:w-44"
              />
            </div>

            <button
              onClick={() => setCurrentPage('cart')}
              className="relative p-2 sm:p-2.5 bg-amber-50 hover:bg-amber-100 rounded-full transition-colors cursor-pointer"
            >
              <ShoppingCart className="w-5 h-5 text-amber-700" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-orange-500 to-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-md animate-bounce">
                  {totalItems}
                </span>
              )}
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-gray-600 hover:text-amber-700 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden pb-4 border-t border-amber-100 pt-3 space-y-2">
            <div className="flex items-center bg-amber-50 rounded-full px-3 py-2 border border-amber-100 mb-3 sm:hidden">
              <Search className="w-4 h-4 text-amber-500 mr-2" />
              <input
                type="text"
                placeholder="Search goodies..."
                value={searchQuery}
                onChange={e => {
                  setSearchQuery(e.target.value);
                  if (currentPage !== 'shop') setCurrentPage('shop');
                }}
                className="bg-transparent text-sm text-gray-700 placeholder-amber-400 outline-none w-full"
              />
            </div>
            {navLinks.map(link => (
              <button
                key={link.page}
                onClick={() => {
                  setCurrentPage(link.page);
                  setMobileMenuOpen(false);
                }}
                className={`block w-full text-left px-4 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
                  currentPage === link.page
                    ? 'bg-amber-100 text-amber-800'
                    : 'text-gray-600 hover:bg-amber-50'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
