import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Sarah M.',
    text: 'The Karma Cookie Jar is absolutely divine! Every cookie tastes like it was made just for me. My kids go crazy for them!',
    rating: 5,
    emoji: '🍪',
  },
  {
    name: 'James L.',
    text: 'Ordered the Cosmic Chocolate Truffles for my anniversary. The packaging was beautiful and the taste was out of this world!',
    rating: 5,
    emoji: '🍫',
  },
  {
    name: 'Priya K.',
    text: 'The Serenity Macaron Set is a work of art. Each flavor is perfectly balanced. Cash on delivery made it so easy!',
    rating: 5,
    emoji: '🧁',
  },
  {
    name: 'Mike R.',
    text: 'Best brownies I\'ve ever had! The Bliss Brownie Box is now a weekly order for our office. Everyone is hooked.',
    rating: 5,
    emoji: '🤎',
  },
];

export default function Testimonials() {
  return (
    <div className="bg-gradient-to-b from-amber-50/50 to-white py-16 sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2
            className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            What Our Customers Say
          </h2>
          <p className="text-gray-500 text-lg">Real reviews from real goodie lovers</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow relative"
            >
              <Quote className="w-8 h-8 text-amber-200 mb-3" />
              <div className="flex items-center gap-1 mb-3">
                {[...Array(t.rating)].map((_, j) => (
                  <Star key={j} className="w-4 h-4 text-amber-400 fill-amber-400" />
                ))}
              </div>
              <p className="text-gray-600 text-sm leading-relaxed mb-4">"{t.text}"</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-200 to-orange-200 flex items-center justify-center text-lg">
                  {t.emoji}
                </div>
                <span className="font-semibold text-gray-800 text-sm">{t.name}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
