import { CheckCircle, Package, Truck, Phone, Mail, MapPin, Calendar, DollarSign, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function OrderConfirmation() {
  const { order, setCurrentPage } = useCart();

  if (!order) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <p className="text-gray-500 text-lg">No order found</p>
        <button onClick={() => setCurrentPage('home')} className="mt-4 text-amber-600 hover:underline cursor-pointer">
          Go home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-16">
      {/* Success Header */}
      <div className="text-center mb-10">
        <div className="relative inline-block mb-6">
          <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center shadow-xl shadow-green-500/30 animate-bounce">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          <div className="absolute -top-2 -right-2 text-2xl animate-pulse">🎉</div>
        </div>

        <h1
          className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3"
          style={{ fontFamily: 'Playfair Display, serif' }}
        >
          Order Confirmed!
        </h1>
        <p className="text-gray-500 text-lg max-w-md mx-auto">
          Thank you for your order! Your goodies are being prepared with love. ✨
        </p>
      </div>

      {/* Order Details Card */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-lg overflow-hidden mb-6">
        {/* Order Header */}
        <div className="bg-gradient-to-r from-amber-500 to-orange-500 px-6 py-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-amber-100 text-sm">Order Number</p>
              <p className="text-xl font-bold">{order.id}</p>
            </div>
            <div className="text-right">
              <p className="text-amber-100 text-sm">Status</p>
              <p className="font-bold flex items-center gap-1">
                <DollarSign className="w-4 h-4" />
                Cash on Delivery
              </p>
            </div>
          </div>
        </div>

        <div className="p-6">
          {/* Delivery Info */}
          <div className="grid sm:grid-cols-2 gap-6 mb-8">
            <div className="space-y-3">
              <h3 className="font-bold text-gray-800 flex items-center gap-2">
                <Truck className="w-4 h-4 text-amber-500" />
                Delivery Details
              </h3>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                  <span>{order.customer.address}, {order.customer.city}, {order.customer.state} {order.customer.zipCode}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  <span>{order.customer.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  <span>{order.customer.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  <span>{order.date}</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="font-bold text-gray-800 flex items-center gap-2">
                <Package className="w-4 h-4 text-amber-500" />
                What's Next?
              </h3>
              <div className="space-y-2">
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="w-3.5 h-3.5 text-green-600" />
                  </div>
                  <span className="text-gray-600">Order confirmed</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse" />
                  </div>
                  <span className="text-gray-600">Being prepared fresh</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <div className="w-2 h-2 bg-gray-400 rounded-full" />
                  </div>
                  <span className="text-gray-400">Out for delivery</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <div className="w-2 h-2 bg-gray-400 rounded-full" />
                  </div>
                  <span className="text-gray-400">Delivered — Pay cash!</span>
                </div>
              </div>
            </div>
          </div>

          {/* Items */}
          <h3 className="font-bold text-gray-800 flex items-center gap-2 mb-4">
            <ShoppingBag className="w-4 h-4 text-amber-500" />
            Items Ordered
          </h3>
          <div className="space-y-3 mb-6">
            {order.items.map(item => (
              <div key={item.id} className="flex items-center gap-4 py-2 border-b border-gray-50 last:border-0">
                <div className="w-14 h-14 rounded-lg overflow-hidden bg-amber-50 flex-shrink-0">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover"
                    onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                  />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-800">{item.name}</p>
                  <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                </div>
                <span className="font-semibold text-gray-800">
                  ${(item.price * item.quantity).toFixed(2)}
                </span>
              </div>
            ))}
          </div>

          {/* Total */}
          <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl p-4 border border-amber-100">
            <div className="flex justify-between items-center">
              <span className="text-lg font-bold text-gray-800">Total (Cash on Delivery)</span>
              <span className="text-2xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                ${order.total.toFixed(2)}
              </span>
            </div>
            <p className="text-sm text-amber-700 mt-2">
              💰 Please keep the exact amount ready for the delivery person
            </p>
          </div>

          {order.customer.notes && (
            <div className="mt-4 p-4 bg-gray-50 rounded-xl">
              <p className="text-sm font-medium text-gray-700 mb-1">Order Notes:</p>
              <p className="text-sm text-gray-600">{order.customer.notes}</p>
            </div>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="text-center space-y-4">
        <button
          onClick={() => setCurrentPage('shop')}
          className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-8 py-3 rounded-full font-semibold shadow-lg shadow-amber-500/25 hover:shadow-xl transition-all cursor-pointer"
        >
          <ShoppingBag className="w-5 h-5" />
          Continue Shopping
        </button>
        <p className="text-sm text-gray-400">
          A confirmation email has been sent to {order.customer.email}
        </p>
      </div>
    </div>
  );
}
