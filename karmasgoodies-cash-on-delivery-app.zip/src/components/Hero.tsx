import { ArrowRight, Star, Truck, Shield, Heart } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function Hero() {
  const { setCurrentPage } = useCart();

  return (
    <div className="relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-amber-50 via-orange-50 to-rose-50" />
      <div className="absolute top-20 left-10 w-72 h-72 bg-amber-200/30 rounded-full blur-3xl" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-orange-200/30 rounded-full blur-3xl" />
      <div className="absolute top-40 right-1/4 w-48 h-48 bg-rose-200/20 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-20 sm:pt-20 sm:pb-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 bg-white/70 backdrop-blur-sm border border-amber-200 rounded-full px-4 py-1.5 mb-6 shadow-sm">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span className="text-sm font-medium text-amber-800">Rated 4.9 by 2,000+ happy customers</span>
            </div>

            <h1
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-gray-900 leading-tight mb-6"
              style={{ fontFamily: 'Playfair Display, serif' }}
            >
              Sweet Treats,{' '}
              <span className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 bg-clip-text text-transparent">
                Good Karma
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-gray-600 mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Handcrafted artisanal goodies made with premium ingredients and positive energy.
              From our kitchen to your doorstep — every bite is a blessing. ✨
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button
                onClick={() => setCurrentPage('shop')}
                className="group inline-flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-8 py-4 rounded-full text-lg font-semibold shadow-lg shadow-amber-500/25 hover:shadow-xl hover:shadow-amber-500/30 transition-all duration-300 hover:-translate-y-0.5 cursor-pointer"
              >
                Shop Goodies
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button
                onClick={() => setCurrentPage('shop')}
                className="inline-flex items-center justify-center gap-2 bg-white hover:bg-amber-50 text-amber-700 border-2 border-amber-200 hover:border-amber-300 px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 cursor-pointer"
              >
                View Menu
              </button>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-6 mt-10 justify-center lg:justify-start">
              <div className="flex items-center gap-2 text-gray-500">
                <Truck className="w-5 h-5 text-amber-500" />
                <span className="text-sm font-medium">Free Delivery</span>
              </div>
              <div className="flex items-center gap-2 text-gray-500">
                <Shield className="w-5 h-5 text-green-500" />
                <span className="text-sm font-medium">Quality Guaranteed</span>
              </div>
              <div className="flex items-center gap-2 text-gray-500">
                <Heart className="w-5 h-5 text-rose-500" />
                <span className="text-sm font-medium">Made with Love</span>
              </div>
            </div>
          </div>

          {/* Right - Image Grid */}
          <div className="relative hidden lg:block">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="rounded-3xl overflow-hidden shadow-xl transform hover:scale-105 transition-transform duration-500">
                  <img
                    src="https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&h=400&fit=crop"
                    alt="Cookies"
                    className="w-full h-48 object-cover"
                  />
                </div>
                <div className="rounded-3xl overflow-hidden shadow-xl transform hover:scale-105 transition-transform duration-500">
                  <img
                    src="https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&h=300&fit=crop"
                    alt="Mochi"
                    className="w-full h-36 object-cover"
                  />
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="rounded-3xl overflow-hidden shadow-xl transform hover:scale-105 transition-transform duration-500">
                  <img
                    src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop"
                    alt="Cake"
                    className="w-full h-36 object-cover"
                  />
                </div>
                <div className="rounded-3xl overflow-hidden shadow-xl transform hover:scale-105 transition-transform duration-500">
                  <img
                    src="https://images.unsplash.com/photo-1569864358642-9d1684040f43?w=400&h=400&fit=crop"
                    alt="Macarons"
                    className="w-full h-48 object-cover"
                  />
                </div>
              </div>
            </div>

            {/* Floating badge */}
            <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 bg-white rounded-2xl shadow-xl px-6 py-3 border border-amber-100">
              <div className="flex items-center gap-3">
                <div className="flex -space-x-2">
                  <div className="w-8 h-8 rounded-full bg-amber-200 flex items-center justify-center text-sm">🍪</div>
                  <div className="w-8 h-8 rounded-full bg-orange-200 flex items-center justify-center text-sm">🧁</div>
                  <div className="w-8 h-8 rounded-full bg-rose-200 flex items-center justify-center text-sm">🍰</div>
                </div>
                <div>
                  <p className="text-sm font-bold text-gray-800">50+ Goodies</p>
                  <p className="text-xs text-gray-500">Fresh daily</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
