import { Leaf, Clock, DollarSign, Gift, Heart, Award } from 'lucide-react';

const features = [
  {
    icon: Leaf,
    title: 'Premium Ingredients',
    description: 'We source only the finest organic and natural ingredients for every recipe.',
    color: 'text-green-500',
    bg: 'bg-green-50',
  },
  {
    icon: Heart,
    title: 'Handcrafted with Love',
    description: 'Every goodie is made by hand in small batches to ensure the highest quality.',
    color: 'text-rose-500',
    bg: 'bg-rose-50',
  },
  {
    icon: Clock,
    title: 'Baked Fresh Daily',
    description: 'We bake every morning so your treats arrive as fresh as possible.',
    color: 'text-blue-500',
    bg: 'bg-blue-50',
  },
  {
    icon: DollarSign,
    title: 'Cash on Delivery',
    description: 'No online payment hassle. Pay with cash when your goodies arrive at your door.',
    color: 'text-amber-500',
    bg: 'bg-amber-50',
  },
  {
    icon: Gift,
    title: 'Beautiful Packaging',
    description: 'Every order is gift-wrapped with care, perfect for any special occasion.',
    color: 'text-purple-500',
    bg: 'bg-purple-50',
  },
  {
    icon: Award,
    title: 'Satisfaction Guaranteed',
    description: "Not happy? We'll make it right. Your satisfaction is our top priority.",
    color: 'text-orange-500',
    bg: 'bg-orange-50',
  },
];

export default function Features() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
      <div className="text-center mb-12">
        <h2
          className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4"
          style={{ fontFamily: 'Playfair Display, serif' }}
        >
          Why KarmasGoodies?
        </h2>
        <p className="text-gray-500 text-lg max-w-2xl mx-auto">
          We're not just another bakery — we're a mission to spread joy through every bite
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, i) => (
          <div
            key={i}
            className="group bg-white rounded-2xl p-6 border border-gray-100 hover:border-amber-200 hover:shadow-lg transition-all duration-300"
          >
            <div className={`w-12 h-12 ${feature.bg} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
              <feature.icon className={`w-6 h-6 ${feature.color}`} />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
            <p className="text-gray-500 text-sm leading-relaxed">{feature.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
