import { Sparkles, Heart, Globe, MessageCircle, Send } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function Footer() {
  const { setCurrentPage } = useCart();

  return (
    <footer className="bg-gradient-to-b from-gray-900 to-gray-950 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-orange-500 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-xl font-bold text-white" style={{ fontFamily: 'Playfair Display, serif' }}>
                  KarmasGoodies
                </span>
              </div>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed mb-4">
              Handcrafted artisanal treats made with premium ingredients and positive energy. Spreading joy, one goodie at a time. ✨
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-9 h-9 bg-gray-800 hover:bg-amber-500 rounded-full flex items-center justify-center transition-colors">
                <Globe className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 bg-gray-800 hover:bg-amber-500 rounded-full flex items-center justify-center transition-colors">
                <MessageCircle className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 bg-gray-800 hover:bg-amber-500 rounded-full flex items-center justify-center transition-colors">
                <Send className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => setCurrentPage('home')} className="text-sm text-gray-400 hover:text-amber-400 transition-colors cursor-pointer">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('shop')} className="text-sm text-gray-400 hover:text-amber-400 transition-colors cursor-pointer">
                  Shop All
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('cart')} className="text-sm text-gray-400 hover:text-amber-400 transition-colors cursor-pointer">
                  Cart
                </button>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-white font-semibold mb-4">Categories</h4>
            <ul className="space-y-2">
              {['Cookies', 'Cakes', 'Macarons', 'Chocolates', 'Brownies'].map(cat => (
                <li key={cat}>
                  <button onClick={() => setCurrentPage('shop')} className="text-sm text-gray-400 hover:text-amber-400 transition-colors cursor-pointer">
                    {cat}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contact Us</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>📧 hello@karmasgoodies.com</li>
              <li>📞 +1 (555) KARMA-00</li>
              <li>📍 123 Goodie Lane, Sweet City</li>
              <li>🕐 Mon-Sat: 8AM - 8PM</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">
            © {new Date().getFullYear()} KarmasGoodies. All rights reserved.
          </p>
          <p className="text-sm text-gray-500 flex items-center gap-1">
            Made with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" /> and good karma
          </p>
        </div>
      </div>
    </footer>
  );
}
