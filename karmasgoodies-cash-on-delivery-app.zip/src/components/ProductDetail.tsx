import { ArrowLeft, Star, ShoppingCart, Minus, Plus, Truck, Shield, RotateCcw, Check } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { products } from '../data/products';
import { useState } from 'react';

export default function ProductDetail() {
  const { selectedProductId, addToCart, setCurrentPage } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const [imgError, setImgError] = useState(false);

  const product = products.find(p => p.id === selectedProductId);

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <p className="text-gray-500 text-lg">Product not found</p>
        <button onClick={() => setCurrentPage('shop')} className="mt-4 text-amber-600 hover:underline cursor-pointer">
          Back to shop
        </button>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Breadcrumb */}
      <button
        onClick={() => setCurrentPage('shop')}
        className="inline-flex items-center gap-2 text-amber-600 hover:text-amber-700 font-medium mb-8 cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Shop
      </button>

      <div className="grid lg:grid-cols-2 gap-8 lg:gap-16">
        {/* Image */}
        <div className="relative">
          <div className="rounded-3xl overflow-hidden shadow-xl bg-amber-50 aspect-square">
            {!imgError ? (
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
                onError={() => setImgError(true)}
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-8xl bg-gradient-to-br from-amber-100 to-orange-100">
                🧁
              </div>
            )}
          </div>
          {product.badge && (
            <span className="absolute top-4 left-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-1.5 rounded-full text-sm font-bold shadow-lg">
              {product.badge}
            </span>
          )}
        </div>

        {/* Details */}
        <div className="flex flex-col">
          <span className="text-sm font-medium text-amber-600 bg-amber-50 px-3 py-1 rounded-full w-fit mb-3">
            {product.category}
          </span>

          <h1
            className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            {product.name}
          </h1>

          {/* Rating */}
          <div className="flex items-center gap-3 mb-6">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-5 h-5 ${i < Math.floor(product.rating) ? 'text-amber-400 fill-amber-400' : 'text-gray-200 fill-gray-200'}`}
                />
              ))}
            </div>
            <span className="text-lg font-semibold text-gray-700">{product.rating}</span>
            <span className="text-gray-400">({product.reviews} reviews)</span>
          </div>

          <p className="text-gray-600 text-lg leading-relaxed mb-6">
            {product.description}
          </p>

          {/* Price */}
          <div className="flex items-baseline gap-3 mb-8">
            <span className="text-4xl font-bold text-gray-900">${product.price.toFixed(2)}</span>
            <span className="text-gray-400 text-sm">per item</span>
          </div>

          {/* Ingredients */}
          {product.ingredients && (
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wider mb-3">Key Ingredients</h3>
              <div className="flex flex-wrap gap-2">
                {product.ingredients.map(ing => (
                  <span key={ing} className="bg-amber-50 text-amber-700 px-3 py-1.5 rounded-full text-sm border border-amber-100">
                    {ing}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Quantity + Add to Cart */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-8">
            <div className="flex items-center border-2 border-amber-200 rounded-full overflow-hidden">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="p-3 hover:bg-amber-50 text-amber-700 transition-colors cursor-pointer"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="px-6 text-lg font-semibold text-gray-800 min-w-[3rem] text-center">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="p-3 hover:bg-amber-50 text-amber-700 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={handleAddToCart}
              className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-8 py-3.5 rounded-full text-lg font-semibold transition-all duration-300 cursor-pointer w-full sm:w-auto ${
                added
                  ? 'bg-green-500 text-white'
                  : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-lg shadow-amber-500/25 hover:shadow-xl'
              }`}
            >
              {added ? (
                <>
                  <Check className="w-5 h-5" />
                  Added to Cart!
                </>
              ) : (
                <>
                  <ShoppingCart className="w-5 h-5" />
                  Add to Cart — ${(product.price * quantity).toFixed(2)}
                </>
              )}
            </button>
          </div>

          {/* Trust */}
          <div className="grid grid-cols-3 gap-4 pt-6 border-t border-gray-100">
            <div className="text-center">
              <Truck className="w-6 h-6 text-amber-500 mx-auto mb-1" />
              <p className="text-xs font-medium text-gray-600">Free Delivery</p>
            </div>
            <div className="text-center">
              <Shield className="w-6 h-6 text-green-500 mx-auto mb-1" />
              <p className="text-xs font-medium text-gray-600">Quality Promise</p>
            </div>
            <div className="text-center">
              <RotateCcw className="w-6 h-6 text-blue-500 mx-auto mb-1" />
              <p className="text-xs font-medium text-gray-600">Easy Returns</p>
            </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mt-16">
          <h2
            className="text-2xl font-bold text-gray-900 mb-6"
            style={{ fontFamily: 'Playfair Display, serif' }}
          >
            You May Also Like
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {relatedProducts.map(p => (
              <button
                key={p.id}
                onClick={() => {
                  window.scrollTo(0, 0);
                  setCurrentPage('product');
                }}
                className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md border border-gray-100 text-left cursor-pointer"
              >
                <div className="aspect-square bg-amber-50 overflow-hidden">
                  <img
                    src={p.image}
                    alt={p.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                  />
                </div>
                <div className="p-3">
                  <h4 className="font-semibold text-gray-800 text-sm truncate">{p.name}</h4>
                  <p className="text-amber-600 font-bold">${p.price.toFixed(2)}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
