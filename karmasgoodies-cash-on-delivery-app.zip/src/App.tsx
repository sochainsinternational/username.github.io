import { CartProvider, useCart } from './context/CartContext';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import FeaturedProducts from './components/FeaturedProducts';
import Features from './components/Features';
import Testimonials from './components/Testimonials';
import CTABanner from './components/CTABanner';
import ProductGrid from './components/ProductGrid';
import ProductDetail from './components/ProductDetail';
import Cart from './components/Cart';
import Checkout from './components/Checkout';
import OrderConfirmation from './components/OrderConfirmation';
import Footer from './components/Footer';
import { useEffect } from 'react';

function ScrollToTop() {
  const { currentPage } = useCart();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);
  return null;
}

function HomePage() {
  return (
    <>
      <Hero />
      <FeaturedProducts />
      <Features />
      <CTABanner />
      <Testimonials />
    </>
  );
}

function PageRouter() {
  const { currentPage } = useCart();

  switch (currentPage) {
    case 'home':
      return <HomePage />;
    case 'shop':
      return <ProductGrid />;
    case 'product':
      return <ProductDetail />;
    case 'cart':
      return <Cart />;
    case 'checkout':
      return <Checkout />;
    case 'confirmation':
      return <OrderConfirmation />;
    default:
      return <HomePage />;
  }
}

function AppContent() {
  return (
    <div className="min-h-screen bg-white flex flex-col" style={{ fontFamily: 'Inter, sans-serif' }}>
      <ScrollToTop />
      <Navbar />
      <main className="flex-1">
        <PageRouter />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <AppContent />
    </CartProvider>
  );
}
